//Encryption.js
//Plan to implement later
module.exports = {
	encrypt: encrypt,
	decrypt: decrypt
};

function encrypt(str){
	return str;
}

function decrypt(str){
	return str;
}